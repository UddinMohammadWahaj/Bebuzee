
// import 'package:flutter/material.dart';

// class NFCScreen extends StatefulWidget {
//   const NFCScreen({Key key}) : super(key: key);

//   @override
//   State<NFCScreen> createState() => _NFCScreenState();
// }

// class _NFCScreenState extends State<NFCScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Container();
//   }
// }
