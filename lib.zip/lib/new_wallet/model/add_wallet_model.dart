// class AddWalletModel {
//   int status;
//   String authenticationUrl;
//   String paymentId;

//   AddWalletModel({this.status, this.authenticationUrl, this.paymentId});

//   AddWalletModel.fromJson(Map<String, dynamic> json) {
//     status = json['status'];
//     authenticationUrl = json['authentication_url'];
//     paymentId = json['payment_id'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['status'] = this.status;
//     data['authentication_url'] = this.authenticationUrl;
//     data['payment_id'] = this.paymentId;
//     return data;
//   }
// }
