
class WalletModel{

  static const String id = "";
  static const String tokenId = "";
  static const String customerId = "";
  static const String cardNumber = "";
  static const String name = "";
  static const String month = "";
  static const String year = "";

}