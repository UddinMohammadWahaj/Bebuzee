// class BalanceModel {
//   int status;
//   int balance;
//   String defaultCardId;

//   BalanceModel({this.status, this.balance, this.defaultCardId});

//   BalanceModel.fromJson(Map<String, dynamic> json) {
//     status = json['status'];
//     balance = json['balance'];
//     defaultCardId = json['default_card_id'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['status'] = this.status;
//     data['balance'] = this.balance;
//     data['default_card_id'] = this.defaultCardId;
//     return data;
//   }
// }
