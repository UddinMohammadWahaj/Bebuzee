class Constant {
  static String PROFILE_URL =
      "https://www.bebuzee.com/upload/images/users/profile/";
}
