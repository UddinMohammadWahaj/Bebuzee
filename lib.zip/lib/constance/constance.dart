import 'package:bizbultest/Language/languageData.dart';

int colorsIndex = 0;

String locale = "en";

AllTextData? allTextData;
