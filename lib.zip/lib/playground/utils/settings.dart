/// Define App ID and Token
const APP_ID = "76906eec8e2148fbbaadf0db5faeb3c6";
// const APP_ID = "a86ce37533fb4d60932f23af4929cfed";

const APP_CERTIFICATE = '6cb9fbcec97b468698144b594905efc5';

var APP_START = false;
var APP_START_LOCAL = false;
bool NOTSTARTED = false;
String PAYLOADSTRING = '';
