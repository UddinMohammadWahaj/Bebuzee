// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';

// class BebuzeeShopDetail extends StatefulWidget {
//   const BebuzeeShopDetail({Key key}) : super(key: key);

//   @override
//   State<BebuzeeShopDetail> createState() => _BebuzeeShopDetailState();
// }

// class _BebuzeeShopDetailState extends State<BebuzeeShopDetail> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(),
//       body: Container(child: ),
//     );
//   }
// }
