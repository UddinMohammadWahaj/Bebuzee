import 'package:flutter/material.dart';

class BuzzerfeedExpanded extends StatefulWidget {
  const BuzzerfeedExpanded({Key? key}) : super(key: key);

  @override
  State<BuzzerfeedExpanded> createState() => _BuzzerfeedExpandedState();
}

class _BuzzerfeedExpandedState extends State<BuzzerfeedExpanded> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
