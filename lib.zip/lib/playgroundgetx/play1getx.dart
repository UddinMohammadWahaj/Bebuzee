// import 'package:dio/dio.dart';
// import 'package:get/get.dart';

// class LocationReviewSearch {
//   final country;
//   final location;
//   LocationReviewSearch(this.country, this.location);
//   Future<List<Map<String, dynamic>>> getResponse(String apiurl) async {
//     return await Dio().get(apiurl).then((value) => value.data);
//   }

//   Future getList(String apiurl) async {
//     return await Future.delayed(Duration(seconds: 1), () => {});
//   }

//   Future getAsync() {
//     Future getAsync() {
//       print("The init has started ");
//       // print("${The process has start}");
//     }
//     // return await Future.delayed(Duration)
//   }
// }
