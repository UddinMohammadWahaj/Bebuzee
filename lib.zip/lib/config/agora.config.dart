/// Get your own App ID at https://dashboard.agora.io/
const appId = "76906eec8e2148fbbaadf0db5faeb3c6";

/// Please refer to https://docs.agora.io/en/Agora%20Platform/token
const token = "00676906eec8e2148fbbaadf0db5faeb3c6IAC5TRXzVHwaM0akGzex5w0GkOzPdnHWiX3q8Um+kFUfR3tTe6gAAAAAEADC2ctrzk9AYQEAAQDNT0Bh";

const certificate = "6cb9fbcec97b468698144b594905efc5";

/// Your channel ID
const channelId = "beeuzee";

/// Your int user ID
const uid = 0;

/// Your string user ID
const stringUid = null;

String firebaseToken = "";
